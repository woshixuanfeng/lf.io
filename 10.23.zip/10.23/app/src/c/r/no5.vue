<template>
	<div id="no5">
		<div style="overflow: hidden;line-height: 50px;">
			<el-breadcrumb separator-class="el-icon-arrow-right" style="float: left;">
				<el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
				<el-breadcrumb-item>养殖基地</el-breadcrumb-item>
			</el-breadcrumb>
		</div>
		<div style="line-height: 100px;text-align: center;">
			<a href="#" style="cursor: pointer;color: #000000;">养殖基地</a>
		</div>
		<div style="text-align: center;">
		     <a href="#" style="cursor: pointer;color: #000000;">BASE</a>
		</div>
		<div style="text-align: center;">
			<a href="#" style="cursor: pointer;"><img style="transition:1s all ease-in;transform: scaleX(0.9); width: 384;height: 288;float: left;margin-left: 40px;margin-top: 15px;" src="https://ccdn.goodq.top/caches/bb156c34ab1478d4698faf5d9b1fed10/aHR0cHM6Ly81Yjk3MzJmOTk0M2M3LnQ3My5xaWZlaXllLmNvbS9xZnktY29udGVudC91cGxvYWRzLzIwMTgvMDkvNjY3ODY0YzNlMjNkNDliNWFiMjc5NzUyMGNhYjUxMjYtNDAweDMwMC5qcGc_p_p100_p_3D.jpg"/></a>
			<a href="#" style="cursor: pointer;"><img style="transition: 1s all ease-in;transform: scaleX(0.9); width: 384;height: 288;float: left;margin-left: 40px;margin-top: 15px;" src="https://ccdn.goodq.top/caches/bb156c34ab1478d4698faf5d9b1fed10/aHR0cHM6Ly81Yjk3MzJmOTk0M2M3LnQ3My5xaWZlaXllLmNvbS9xZnktY29udGVudC91cGxvYWRzLzIwMTgvMDkvMWU4ZWQ4OTMzOGRmYmY2ZmE1NTJmNDlkZTRhZjlmYjItNDAweDMwMC5qcGc_p_p100_p_3D.jpg"/></a>
			<a href="#" style="cursor: pointer;"><img style="transition: 1s all ease-in;transform: scaleX(0.9);width: 384;height: 288;float: left;margin-left: 40px;margin-top: 15px;" src="https://ccdn.goodq.top/caches/bb156c34ab1478d4698faf5d9b1fed10/aHR0cHM6Ly81Yjk3MzJmOTk0M2M3LnQ3My5xaWZlaXllLmNvbS9xZnktY29udGVudC91cGxvYWRzLzIwMTgvMDkvOGQ3MmM5MGNmMzAyZDZmMDZkMjc5NjFjYmIxMDljOTctNDAweDMwMC5qcGc_p_p100_p_3D.jpg"/></a>
		</div>
		<div style="text-align: center;">
			<a href="#" style="cursor: pointer;"><img style="transition: 1s all ease-in;transform: scaleX(0.9);width: 384;height: 288;float: left;margin-left: 40px;margin-top: 15px;" src="https://ccdn.goodq.top/caches/bb156c34ab1478d4698faf5d9b1fed10/aHR0cHM6Ly81Yjk3MzJmOTk0M2M3LnQ3My5xaWZlaXllLmNvbS9xZnktY29udGVudC91cGxvYWRzLzIwMTgvMDkvOTliZmYyNDViZmVmNWM0ZjVlMWZkYTcyNWM2NjRhNDMtNDAweDMwMC5qcGc_p_p100_p_3D.jpg"/></a>
			<a href="#" style="cursor: pointer;"><img style="transition: 1s all ease-in;transform: scaleX(0.9);width: 384;height: 288;float: left;margin-left: 40px;margin-top: 15px;" src="https://ccdn.goodq.top/caches/bb156c34ab1478d4698faf5d9b1fed10/aHR0cHM6Ly81Yjk3MzJmOTk0M2M3LnQ3My5xaWZlaXllLmNvbS9xZnktY29udGVudC91cGxvYWRzLzIwMTgvMDkvMWNhZDZjYTc5NGQ4NDE5ZWE0NDg4ZDI2MGVjZDdmNGUtNDAweDMwMC5qcGc_p_p100_p_3D.jpg"/></a>
			<a href="#" style="cursor: pointer;"><img style="transition: 1s all ease-in;transform: scaleX(0.9);width: 384;height: 288;float: left;margin-left: 40px;margin-top: 15px;" src="https://ccdn.goodq.top/caches/bb156c34ab1478d4698faf5d9b1fed10/aHR0cHM6Ly81Yjk3MzJmOTk0M2M3LnQ3My5xaWZlaXllLmNvbS9xZnktY29udGVudC91cGxvYWRzLzIwMTgvMDkvMWZkN2IyNDY5ZDBiZmMzZDgzNTQ1NjkyZDcxMzQ5NmMtNDAweDMwMC5qcGc_p_p100_p_3D.jpg"/></a>
		</div>
	</div>
</template>

<script>
</script>
    
<style>
	*{
		margin: 0;
		padding: 0;
		text-decoration: none;
	}
</style>